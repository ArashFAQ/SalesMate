# -*- coding: utf-8 -*-
"""صفحهٔ «چک‌ها» (فقط مالک) — لیست، سررسید، مشتریان و پیش‌بینی هفتگی."""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTabWidget, QTableWidget, QTableWidgetItem,
    QLineEdit, QComboBox, QFileDialog, QMessageBox, QDialog, QHeaderView, QCheckBox, QAbstractItemView,
)
from PySide6.QtGui import QColor

try:
    import app_core as core
    import cheque_core as cc
    from core_utils import fa_digits, customer_key
except Exception:  # pragma: no cover
    from salesmate import app_core as core
    from salesmate import cheque_core as cc
    from salesmate.core_utils import fa_digits, customer_key

DB_NAME = "cheques.db"
CLR = {cc.ST_HAND: "#475569", cc.ST_TRANSIT: "#b45309", cc.ST_DONE: "#15803d", cc.ST_BACK: "#b91c1c"}


def _swallow():
    try:
        core._swallow()
    except Exception:
        pass


def db_path():
    return core.APP_DIR / DB_NAME


def money(v):
    try:
        return fa_digits("{:,}".format(int(v)))
    except Exception:
        return fa_digits(str(v))


def _item(text, color=None, align=Qt.AlignCenter):
    it = QTableWidgetItem(fa_digits(str(text)))
    it.setTextAlignment(align)
    it.setFlags(it.flags() & ~Qt.ItemIsEditable)
    if color:
        it.setForeground(QColor(color))
    return it


def _table(headers):
    t = QTableWidget(0, len(headers))
    t.setHorizontalHeaderLabels(headers)
    t.setLayoutDirection(Qt.RightToLeft)
    t.setEditTriggers(QAbstractItemView.NoEditTriggers)
    t.setSelectionBehavior(QAbstractItemView.SelectRows)
    t.verticalHeader().setVisible(False)
    t.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
    return t


_TR_CACHE = {"stamp": None, "map": {}}
_CW_CACHE = {"at": 0.0, "map": {}, "busy": False}


def owner_mode():
    """مالک (یا حساب ناشناخته) = چک‌ها از فایل محلی؛ همکار = فقط ردیف خودش از ابر."""
    try:
        em = core.supabase_user_info().get("email") or ""
    except Exception:
        em = ""
    if not em:
        return True
    try:
        try:
            import coworker_core as _cw
        except Exception:
            from salesmate import coworker_core as _cw
        return bool(_cw.is_owner_email(em))
    except Exception:
        return True


def _cw_cache_path():
    return core.APP_DIR / "coworker_cheques.json"


def _cw_fetch():
    """ردیف cheques همکار از coworker_snapshots (فقط ردیف خودش)؛ در فایل محلی هم کش می‌شود."""
    import json
    uid = core.supabase_user_info().get("user_id") or ""
    if not uid:
        return None
    _st, rows = core.supabase_request("GET", "/rest/v1/coworker_snapshots?assignee=eq.%s&select=cheques" % uid)
    payload = (rows[0].get("cheques") if rows else None) or {}
    try:
        _cw_cache_path().write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    except Exception:
        _swallow()
    return payload


def _cw_build(payload):
    return cc.transit_by_customer(cc.cloud_rows_to_recs(payload), customer_key)


def _cw_map():
    import json, threading, time
    now = time.time()
    if not _CW_CACHE["map"] and _CW_CACHE["at"] == 0.0:        # اولین بار: کش محلی، بعد دریافت همزمان
        _CW_CACHE["at"] = 1.0
        try:
            _CW_CACHE["map"] = _cw_build(json.loads(_cw_cache_path().read_text(encoding="utf-8")))
        except Exception:
            pass
        try:
            p = _cw_fetch()
            if p is not None:
                _CW_CACHE["map"] = _cw_build(p)
                _CW_CACHE["at"] = now
        except Exception:
            _swallow()
    elif now - _CW_CACHE["at"] > 600 and not _CW_CACHE["busy"]:   # تازه‌سازی پس‌زمینه
        _CW_CACHE["busy"] = True

        def run():
            try:
                p = _cw_fetch()
                if p is not None:
                    _CW_CACHE["map"] = _cw_build(p)
                _CW_CACHE["at"] = time.time()
            except Exception:
                _swallow()
            finally:
                _CW_CACHE["busy"] = False
        threading.Thread(target=run, daemon=True).start()
    return _CW_CACHE["map"]


def transit_map():
    """نقشهٔ چک‌های در راه هر مشتری: مالک از فایل محلی (کش بر اساس تغییر فایل و روز)، همکار از ابر."""
    try:
        if not owner_mode():
            return _cw_map()
        p = db_path()
        stamp = (p.stat().st_mtime, __import__("datetime").date.today()) if p.exists() else None
        if stamp is None:
            return {}
        if _TR_CACHE["stamp"] != stamp:
            _TR_CACHE["map"] = cc.transit_by_customer(cc.load_all(p), customer_key)
            _TR_CACHE["stamp"] = stamp
        return _TR_CACHE["map"]
    except Exception:
        _swallow()
        return {}


def transit_for(name):
    return transit_map().get(customer_key(name), [])


_TW = 800          # عرض منطقی بوم
_RH = 36           # ارتفاع هر ردیف
_FIX_H = 64 + 12 + 68 + 12 + 32 + 20
_TOTAL_H = 12 + 48


def _qfont(size, bold=False):
    from PySide6.QtGui import QFont
    f = QFont()
    f.setFamilies(["Vazirmatn", "Segoe UI", "Tahoma", "Arial", "DejaVu Sans"])
    f.setPixelSize(int(size))
    if bold:
        f.setWeight(QFont.Bold)
    return f


def transit_height(n, last=True):
    return _FIX_H + n * _RH + (_TOTAL_H if last else 0)


def draw_transit_page(p, name, rows, start, last, total, page_no=1, pages=1):
    """ترسیم یک صفحه با قالب فرم استعلام: سربرگ آبی، دو باکس (مشتری/تاریخ)، جدول آبی، جمع کل."""
    from PySide6.QtCore import QRect, QRectF
    from PySide6.QtGui import QColor, QPen, QBrush
    W, M = _TW, 16
    blue, white = QColor("#1565C0"), QColor("#FFFFFF")

    def fill(rect, col, r=0):
        p.setPen(Qt.NoPen)
        p.setBrush(QBrush(col))
        if r:
            p.drawRoundedRect(QRectF(rect), r, r)
        else:
            p.drawRect(rect)

    def text(rect, flags, t, font, col):
        p.setFont(font)
        p.setPen(QPen(QColor(col)))
        p.drawText(rect, flags, t)

    fill(QRect(0, 0, W, 64), blue)
    text(QRect(M, 0, W - 2 * M, 64), Qt.AlignRight | Qt.AlignVCenter, "چک‌های در راه", _qfont(20, True), "#FFFFFF")
    text(QRect(M, 0, W - 2 * M, 64), Qt.AlignLeft | Qt.AlignVCenter, "SalesMate", _qfont(12), "#DCEBFA")
    y = 76
    bw = int((W - 2 * M - 12) * 0.64)
    dw = W - 2 * M - 12 - bw
    fill(QRect(W - M - bw, y, bw, 68), blue, 12)
    fill(QRect(M, y, dw, 68), blue, 12)
    text(QRect(W - M - bw + 16, y + 8, bw - 32, 20), Qt.AlignRight | Qt.AlignVCenter, "نام مشتری", _qfont(11), "#CFE3F7")
    text(QRect(W - M - bw + 16, y + 30, bw - 32, 32), Qt.AlignRight | Qt.AlignVCenter, name, _qfont(17, True), "#FFFFFF")
    text(QRect(M + 16, y + 8, dw - 32, 20), Qt.AlignRight | Qt.AlignVCenter, "تاریخ گزارش", _qfont(11), "#CFE3F7")
    text(QRect(M + 16, y + 30, dw - 32, 32), Qt.AlignLeft | Qt.AlignVCenter, fa_digits(cc.today_jalali()), _qfont(17, True), "#FFFFFF")
    y += 68 + 12
    TW = W - 2 * M
    fr = [0.10, 0.25, 0.30, 0.35]          # از راست: ردیف، تاریخ، شماره چک، مبلغ
    cols, x = [], W - M
    for f in fr:
        w = int(TW * f)
        cols.append(QRect(x - w, 0, w, 0))
        x -= w
    top = y
    fill(QRect(M, y, TW, 32), blue)
    for c, h in zip(cols, ["ردیف", "تاریخ چک", "شماره چک", "مبلغ (ریال)"]):
        text(QRect(c.x(), y, c.width(), 32), Qt.AlignCenter, h, _qfont(12, True), "#FFFFFF")
    y += 32
    for i, r in enumerate(rows):
        fill(QRect(M, y, TW, _RH), QColor("#F0F9FF") if i % 2 == 0 else white)
        fill(QRect(M, y + _RH - 1, TW, 1), QColor("#E0F2FE"))
        vals = [fa_digits(start + i + 1), fa_digits(r["due_date"]), fa_digits(str(r["cheque_no"])), money(r["amount"])]
        for j, (c, v) in enumerate(zip(cols, vals)):
            text(QRect(c.x(), y, c.width(), _RH), Qt.AlignCenter, v, _qfont(13, j == 3), "#0F172A")
        y += _RH
    p.setBrush(Qt.NoBrush)
    p.setPen(QPen(QColor("#BAE6FD"), 1))
    p.drawRect(QRect(M, top, TW, y - top))
    if last:
        y += 12
        fill(QRect(M, y, TW, 48), QColor("#FFF7ED"), 12)
        text(QRect(M + 16, y, TW - 32, 48), Qt.AlignRight | Qt.AlignVCenter, "جمع کل چک‌های در راه", _qfont(14, True), "#64748B")
        text(QRect(M + 16, y, TW - 32, 48), Qt.AlignLeft | Qt.AlignVCenter, money(total) + " ریال", _qfont(18, True), "#B45309")
    if pages > 1:
        text(QRect(0, y + 8, W, 20), Qt.AlignCenter, fa_digits("صفحه %d از %d" % (page_no, pages)), _qfont(10), "#94A3B8")


def render_transit_image(name, rows, scale=2):
    from PySide6.QtGui import QImage, QPainter
    H = transit_height(len(rows))
    img = QImage(_TW * scale, H * scale, QImage.Format_ARGB32)
    img.fill(QColor("#FFFFFF"))
    p = QPainter(img)
    p.setRenderHint(QPainter.Antialiasing, True)
    p.setRenderHint(QPainter.TextAntialiasing, True)
    p.scale(scale, scale)
    draw_transit_page(p, name, rows, 0, True, cc.sum_amount(rows))
    p.end()
    return img


def export_transit_pdf(name, rows, path):
    from PySide6.QtGui import QPdfWriter, QPageSize, QPageLayout, QPainter
    from PySide6.QtCore import QMarginsF
    w = QPdfWriter(path)
    w.setPageSize(QPageSize(QPageSize.A4))
    w.setPageMargins(QMarginsF(8, 8, 8, 8), QPageLayout.Millimeter)
    pr = w.pageLayout().paintRectPixels(w.resolution())
    sc = pr.width() / float(_TW)
    hlog = pr.height() / sc
    per = max(5, int((hlog - _FIX_H - _TOTAL_H - 30) // _RH))
    chunks = [rows[i:i + per] for i in range(0, len(rows), per)] or [[]]
    p = QPainter(w)
    p.setRenderHint(QPainter.Antialiasing, True)
    p.setRenderHint(QPainter.TextAntialiasing, True)
    total = cc.sum_amount(rows)
    for k, ch in enumerate(chunks):
        if k:
            w.newPage()
        p.save()
        p.scale(sc, sc)
        draw_transit_page(p, name, ch, k * per, k == len(chunks) - 1, total, k + 1, len(chunks))
        p.restore()
    p.end()


class TransitDialog(QDialog):
    """چک‌های در راه یک مشتری: تاریخ، شماره چک، مبلغ + جمع کل؛ خروجی عکس و PDF با قالب فرم استعلام."""
    def __init__(self, parent, name, rows):
        super().__init__(parent)
        self.name, self.rows = name, rows
        self.setWindowTitle("چک‌های در راه — " + name)
        self.setLayoutDirection(Qt.RightToLeft)
        try:
            av = QApplication.primaryScreen().availableGeometry()
            self.resize(min(1000, int(av.width() * 0.8)), min(640, int(av.height() * 0.78)))
        except Exception:
            self.resize(980, 600)
        lay = QVBoxLayout(self)
        # دکمه‌ها بالا (همیشه دیده می‌شوند)؛ پیش‌نمایش پایین با اسکرول عمودی
        row = QHBoxLayout()
        for text, col, fn in (("ذخیره عکس (PNG)", "#1565C0", self.save_png), ("ذخیره PDF", "#059669", self.save_pdf),
                              ("بستن", "#64748B", self.accept)):
            b = QPushButton(text)
            b.setCursor(Qt.PointingHandCursor)
            b.setStyleSheet("QPushButton{background:%s;color:#fff;border:none;border-radius:10px;padding:9px 18px;font-weight:700;}" % col)
            b.clicked.connect(fn)
            row.addWidget(b)
        row.addStretch(1)
        lay.addLayout(row)
        from PySide6.QtWidgets import QScrollArea
        self._img = render_transit_image(name, rows, 2)
        self.lbl = QLabel()
        self.lbl.setAlignment(Qt.AlignTop | Qt.AlignHCenter)
        self.sc = QScrollArea()
        self.sc.setWidgetResizable(True)
        self.sc.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)   # بدون اسکرول چپ/راست؛ پیش‌نمایش با عرض پنجره تنظیم می‌شود
        self.sc.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.sc.setWidget(self.lbl)
        lay.addWidget(self.sc, 1)
        self._fit()

    def _fit(self):
        from PySide6.QtGui import QPixmap
        w = max(300, self.sc.viewport().width() - 6)
        self.lbl.setPixmap(QPixmap.fromImage(self._img).scaledToWidth(w, Qt.SmoothTransformation))

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        try:
            self._fit()
        except Exception:
            _swallow()

    def showEvent(self, ev):
        super().showEvent(ev)
        try:
            self._fit()
        except Exception:
            _swallow()

    def _fname(self, ext):
        import re
        safe = re.sub(r"[\\/:*?\"<>|]+", "_", self.name).strip() or "customer"
        return "چک_در_راه_%s.%s" % (safe, ext)

    def save_png(self):
        path, _ = QFileDialog.getSaveFileName(self, "ذخیره عکس", self._fname("png"), "PNG (*.png)")
        if not path:
            return
        if not path.lower().endswith(".png"):
            path += ".png"
        try:
            ok = render_transit_image(self.name, self.rows, 2).save(path, "PNG")
            QMessageBox.information(self, "ذخیره", ("عکس ذخیره شد:\n" + path) if ok else "ذخیره عکس انجام نشد.")
        except Exception as ex:
            QMessageBox.warning(self, "ذخیره", "ذخیره عکس انجام نشد:\n" + str(ex))

    def save_pdf(self):
        path, _ = QFileDialog.getSaveFileName(self, "ذخیره PDF", self._fname("pdf"), "PDF (*.pdf)")
        if not path:
            return
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
        try:
            export_transit_pdf(self.name, self.rows, path)
            QMessageBox.information(self, "ذخیره", "PDF ذخیره شد:\n" + path)
        except Exception as ex:
            QMessageBox.warning(self, "ذخیره", "ذخیره PDF انجام نشد:\n" + str(ex))


class CustomerChequeDialog(QDialog):
    def __init__(self, parent, name, recs):
        super().__init__(parent)
        self.setWindowTitle("چک‌های " + name)
        self.setLayoutDirection(Qt.RightToLeft)
        self.resize(900, 560)
        s = cc.customer_summary(recs, name, customer_key)
        lay = QVBoxLayout(self)
        try:
            bal = core.customer_balance(name)
            btxt = ("بدهکار %s ریال" % money(bal)) if bal > 0 else ("طلبکار %s ریال" % money(-bal)) if bal < 0 else "تسویه ✓"
        except Exception:
            btxt = "—"
        t = s["tot"]
        head = QLabel(
            "<b>%s</b><br>مانده حساب (حواله‌ها): %s<br>"
            "چک در دست: %s | در راه (واگذار شده): %s | وصول شده: %s | برگشتی: %s"
            % (name, btxt, money(t[cc.ST_HAND]["sum"]), money(t[cc.ST_TRANSIT]["sum"]),
               money(t[cc.ST_DONE]["sum"]), money(t[cc.ST_BACK]["sum"])))
        head.setTextFormat(Qt.RichText)
        head.setWordWrap(True)
        lay.addWidget(head)
        note = QLabel("چک‌ها فقط نمایش داده می‌شوند و روی مانده حساب اثری ندارند.")
        note.setStyleSheet("color:#64748b;")
        lay.addWidget(note)
        tb = _table(["شماره چک", "بانک", "سررسید", "مبلغ", "وضعیت", "تاریخ وصول/برگشت"])
        fill_rows(tb, s["rows"], mode="cust")
        lay.addWidget(tb, 1)
        b = QPushButton("بستن")
        b.clicked.connect(self.accept)
        lay.addWidget(b)


def fill_rows(tb, rows, mode="list"):
    tb.setRowCount(len(rows))
    for i, r in enumerate(rows):
        col = CLR.get(r["status"])
        if mode == "cust":
            vals = [r["cheque_no"], r["bank"], r["due_date"], money(r["amount"]), cc.ST_LABEL[r["status"]],
                    r["returned_date"] or r["collected_date"]]
        elif mode == "due":
            left = r.get("left", 0)
            vals = [r["party"], r["cheque_no"], r["bank"], r["due_date"], money(r["amount"]),
                    ("%d روز گذشته" % -left) if left < 0 else ("امروز" if left == 0 else "%d روز دیگر" % left)]
        else:
            vals = [r["party"], r["cheque_no"], r["bank"], r["due_date"], money(r["amount"]),
                    cc.ST_LABEL[r["status"]], r["handed_date"], r["collected_date"], r["returned_date"]]
        for j, v in enumerate(vals):
            c = None
            if mode != "due" and ((mode == "cust" and j == 4) or (mode == "list" and j == 5)):
                c = col
            if mode == "due" and j == 5 and r.get("left", 0) < 0:
                c = "#b91c1c"
            tb.setItem(i, j, _item(v, c))
        tb.item(i, 0).setData(Qt.UserRole, r["party"])


class ChequePage(QWidget):
    def __init__(self, win):
        super().__init__()
        self.win = win
        self.recs = []
        self.setLayoutDirection(Qt.RightToLeft)
        lay = QVBoxLayout(self)
        top = QHBoxLayout()
        title = QLabel("<b>چک‌ها و واریزی‌های مشتریان</b> (محرمانه — فقط روی همین رایانه ذخیره می‌شود)")
        top.addWidget(title, 1)
        self.imp = QPushButton("📥 بارگذاری اکسل چک‌ها")
        self.imp.clicked.connect(self.import_excel)
        top.addWidget(self.imp)
        lay.addLayout(top)
        self.cards = QLabel("")
        self.cards.setTextFormat(Qt.RichText)
        self.cards.setWordWrap(True)
        lay.addWidget(self.cards)
        self.tabs = QTabWidget()
        lay.addWidget(self.tabs, 1)

        # لیست
        w = QWidget(); l = QVBoxLayout(w)
        f = QHBoxLayout()
        self.st = QComboBox(); self.st.addItem("همهٔ وضعیت‌ها", None)
        for k, v in cc.ST_LABEL.items():
            self.st.addItem(v, k)
        self.bank = QComboBox()
        self.txt = QLineEdit(); self.txt.setPlaceholderText("جستجو: مشتری / شماره چک")
        self.dfrom = QLineEdit(); self.dfrom.setPlaceholderText("سررسید از 1405/01/01")
        self.dto = QLineEdit(); self.dto.setPlaceholderText("تا 1405/12/29")
        self.sales = QCheckBox("فقط چک مشتری‌ها (بدون اجاره/سود/شخصی)"); self.sales.setChecked(True)
        for x in (self.st, self.bank, self.txt, self.dfrom, self.dto, self.sales):
            f.addWidget(x)
            if isinstance(x, QComboBox):
                x.currentIndexChanged.connect(self.refresh_list)
            elif isinstance(x, QLineEdit):
                x.textChanged.connect(self.refresh_list)
            else:
                x.stateChanged.connect(self.refresh_list)
        l.addLayout(f)
        self.sum_lbl = QLabel(""); l.addWidget(self.sum_lbl)
        self.tb_list = _table(["مشتری", "شماره چک", "بانک", "سررسید", "مبلغ", "وضعیت", "واگذاری", "وصول", "برگشت"])
        self.tb_list.cellDoubleClicked.connect(lambda r, c: self._open_cust(self.tb_list, r))
        l.addWidget(self.tb_list, 1)
        self.tabs.addTab(w, "لیست چک‌ها")

        # سررسید
        w = QWidget(); l = QVBoxLayout(w)
        self.due_tabs = {}
        self.due_lbl = QLabel(""); self.due_lbl.setTextFormat(Qt.RichText); l.addWidget(self.due_lbl)
        self.due_sel = QComboBox()
        for k, v in [("overdue", "⚠ سررسید گذشته (تا ۱ سال) و وصول‌نشده"), ("old", "قدیمی (بیش از ۱ سال، اغلب موجودی اول دوره)"), ("w7", "۷ روز آینده"),
                     ("d30", "۸ تا ۳۰ روز آینده"), ("later", "بعد از ۳۰ روز")]:
            self.due_sel.addItem(v, k)
        self.due_sel.currentIndexChanged.connect(self.refresh_due)
        l.addWidget(self.due_sel)
        self.tb_due = _table(["مشتری", "شماره چک", "بانک", "سررسید", "مبلغ", "زمان"])
        self.tb_due.cellDoubleClicked.connect(lambda r, c: self._open_cust(self.tb_due, r))
        l.addWidget(self.tb_due, 1)
        self.tabs.addTab(w, "سررسیدها")

        # مشتریان
        w = QWidget(); l = QVBoxLayout(w)
        l.addWidget(QLabel("با دوبار کلیک روی هر مشتری، چک‌ها و مانده حسابش نمایش داده می‌شود."))
        self.cust_search = QLineEdit(); self.cust_search.setPlaceholderText("🔍 جستجوی مشتری…")
        self.cust_search.setClearButtonEnabled(True)
        self.cust_search.textChanged.connect(lambda *_: self.refresh_customers())
        l.addWidget(self.cust_search)
        self.tb_cust = _table(["مشتری", "در دست", "در راه", "وصول‌شده", "برگشتی", "تعداد چک"])
        self.tb_cust.cellDoubleClicked.connect(lambda r, c: self._open_cust(self.tb_cust, r))
        l.addWidget(self.tb_cust, 1)
        self.tabs.addTab(w, "مشتریان")

        # پیش‌بینی
        w = QWidget(); l = QVBoxLayout(w)
        l.addWidget(QLabel("جمع چک‌های باز (در دست + در راه) بر اساس هفتهٔ سررسید، از امروز."))
        self.tb_flow = _table(["بازه", "از تاریخ", "تا تاریخ", "تعداد چک", "جمع مبلغ (ریال)"])
        l.addWidget(self.tb_flow, 1)
        self.tabs.addTab(w, "پیش‌بینی هفتگی")
        self.reload()

    # ----- داده -----
    def reload(self):
        try:
            self.recs = cc.load_all(db_path())
        except Exception:
            _swallow()
            self.recs = []
        banks = sorted({r["bank"] for r in self.recs if r["bank"]})
        self.bank.blockSignals(True)
        self.bank.clear(); self.bank.addItem("همهٔ بانک‌ها", None)
        for b in banks:
            self.bank.addItem(b, b)
        self.bank.blockSignals(False)
        self.refresh()

    def on_show(self):
        self.reload()

    def refresh(self):
        sales = [r for r in self.recs if r["is_sales"]]
        if not self.recs:
            self.cards.setText("هنوز اکسل چک‌ها بارگذاری نشده. دکمهٔ «بارگذاری اکسل چک‌ها» را بزنید.")
        else:
            t = cc.totals_by_status(sales)
            self.cards.setText(" &nbsp;|&nbsp; ".join(
                "<span style='color:%s'><b>%s</b>: %s چک — %s ریال</span>"
                % (CLR[k], cc.ST_LABEL[k], fa_digits(t[k]["n"]), money(t[k]["sum"])) for k in cc.ST_LABEL))
        self.refresh_list(); self.refresh_due(); self.refresh_customers(); self.refresh_flow()

    def refresh_list(self, *a):
        rows = cc.filter_rows(self.recs, self.st.currentData(), self.bank.currentData(), self.txt.text(),
                              self.dfrom.text(), self.dto.text(), self.sales.isChecked())
        rows.sort(key=lambda r: r["due_date"], reverse=True)
        self.sum_lbl.setText("%s چک — جمع %s ریال" % (fa_digits(len(rows)), money(cc.sum_amount(rows))))
        fill_rows(self.tb_list, rows[:3000], "list")

    def refresh_due(self, *a):
        sales = [r for r in self.recs if r["is_sales"]]
        g = cc.due_report(sales)
        self.due_lbl.setText(" | ".join("%s: %s چک — %s ریال" % (n, fa_digits(len(g[k])), money(cc.sum_amount(g[k])))
                                       for k, n in [("overdue", "سررسید گذشته"), ("old", "قدیمی"), ("w7", "۷ روز"),
                                                    ("d30", "۳۰ روز"), ("later", "بعدتر")]))
        fill_rows(self.tb_due, g[self.due_sel.currentData()], "due")

    def refresh_customers(self):
        rows = cc.customer_table([r for r in self.recs], customer_key)
        q = customer_key(self.cust_search.text()) if hasattr(self, "cust_search") else ""
        if q:
            rows = [e for e in rows if q in customer_key(e["name"])]
        self.tb_cust.setRowCount(len(rows))
        for i, e in enumerate(rows):
            vals = [e["name"], money(e["hand"]), money(e["transit"]), money(e["done"]), money(e["back"]), e["n"]]
            for j, v in enumerate(vals):
                self.tb_cust.setItem(i, j, _item(v, "#b91c1c" if j == 4 and e["back"] else None))
            self.tb_cust.item(i, 0).setData(Qt.UserRole, e["name"])

    def refresh_flow(self):
        rows = cc.weekly_flow([r for r in self.recs if r["is_sales"]])
        self.tb_flow.setRowCount(len(rows))
        for i, w in enumerate(rows):
            fr = cc.today_jalali(w["from"]) if w.get("from") else ""
            to = cc.today_jalali(w["to"]) if w.get("to") else ""
            for j, v in enumerate([w["label"], fr, to, w["n"], money(w["sum"])]):
                self.tb_flow.setItem(i, j, _item(v, "#b91c1c" if i == 1 and w["n"] else None))

    def _open_cust(self, tb, row):
        it = tb.item(row, 0)
        name = it.data(Qt.UserRole) if it else None
        if name:
            CustomerChequeDialog(self, name, self.recs).exec()

    def import_excel(self):
        path, _ = QFileDialog.getOpenFileName(self, "اکسل چک‌ها", "", "Excel (*.xlsx *.xlsm)")
        if not path:
            return
        try:
            recs = cc.read_workbook(path)
            if not recs:
                QMessageBox.warning(self, "چک‌ها", "ردیف چکی در فایل پیدا نشد (ساختار شیت AMISA لازم است).")
                return
            old = len(self.recs)
            if old:
                box = QMessageBox(self)
                box.setWindowTitle("چک‌ها")
                box.setText("از قبل %s چک ثبت است. فایل جدید چطور وارد شود؟" % fa_digits(old))
                b_merge = box.addButton("ادغام (پیشنهادی: قبلی‌ها می‌مانند، وضعیت‌ها به‌روز می‌شود)", QMessageBox.AcceptRole)
                b_repl = box.addButton("جایگزینی کامل (قبلی‌ها پاک می‌شود)", QMessageBox.DestructiveRole)
                box.addButton("لغو", QMessageBox.RejectRole)
                box.exec()
                clicked = box.clickedButton()
                if clicked is b_merge:
                    a, u, k = cc.merge_into(db_path(), recs)
                    QMessageBox.information(self, "چک‌ها", "ادغام انجام شد:\n%s چک جدید، %s چک به‌روز شد، %s چک قبلی حفظ شد." % (
                        fa_digits(a), fa_digits(u), fa_digits(k)))
                elif clicked is b_repl:
                    import shutil
                    try:
                        shutil.copyfile(str(db_path()), str(db_path()) + ".bak")
                    except Exception:
                        _swallow()
                    n = cc.replace_all(db_path(), recs)
                    QMessageBox.information(self, "چک‌ها", "%s چک بارگذاری شد (قبلی‌ها جایگزین شد؛ نسخه پشتیبان: cheques.db.bak)." % fa_digits(n))
                else:
                    return
            else:
                n = cc.replace_all(db_path(), recs)
                QMessageBox.information(self, "چک‌ها", "%s چک بارگذاری شد." % fa_digits(n))
        except Exception as e:
            _swallow()
            QMessageBox.warning(self, "چک‌ها", "خطا در خواندن فایل: %s" % e)
        self.reload()
        _TR_CACHE["stamp"] = None
        self._push_mobile()

    def _push_mobile(self):
        """چک‌های در راه مشتری‌های خود مالک را برای اپ موبایل (فقط مالک) به ابر می‌فرستد؛ بی‌صدا اگر ابر در دسترس نباشد."""
        import threading

        def run():
            try:
                core.push_mobile_snapshots(force=True)
            except Exception:
                _swallow()
        threading.Thread(target=run, daemon=True).start()
