# -*- coding: utf-8 -*-
"""چک‌ها و واریزی‌های مشتری‌ها — هستهٔ بدون Qt (قابل تست).

محرمانه: داده فقط در فایل محلی «cheques.db» کنار برنامه نگه‌داری می‌شود؛
همگام‌سازی ابری، پشتیبان ابری و GitHub آن را نمی‌برند.

وضعیت هر چک از روی تاریخ‌های فایل اکسل:
  برگشتی   = «تاریخ برگشت» پر است
  وصول‌شده = «تاریخ وصول» پر است
  در راه   = «تاریخ واگذاری» پر است ولی هنوز وصول/برگشت نخورده
  در دست   = هیچ‌کدام (هنوز واگذار نشده)
"""
import re
import sqlite3
from datetime import date, datetime

_FA = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")

ST_HAND, ST_TRANSIT, ST_DONE, ST_BACK = "hand", "transit", "done", "back"
ST_LABEL = {ST_HAND: "در دست", ST_TRANSIT: "واگذار شده (وصول‌نشده)", ST_DONE: "وصول شده", ST_BACK: "برگشتی"}
OPEN_STATES = (ST_HAND, ST_TRANSIT)
OLD_DAYS = 365

COLS = ["row_no", "form_no", "form_date", "cheque_no", "due_date", "amount", "bank",
        "handed_date", "collected_date", "returned_date", "days", "descr", "party", "account"]

SCHEMA = """CREATE TABLE IF NOT EXISTS cheques(
    row_no INTEGER, form_no TEXT, form_date TEXT, cheque_no TEXT, due_date TEXT,
    amount INTEGER, bank TEXT, handed_date TEXT, collected_date TEXT, returned_date TEXT,
    days INTEGER, descr TEXT, party TEXT, account TEXT, status TEXT, is_sales INTEGER)"""


def _s(v):
    if v is None:
        return ""
    if isinstance(v, float) and v != v:
        return ""
    return str(v).translate(_FA).strip()


def _num(v):
    t = re.sub(r"[^\d.\-]", "", _s(v).replace(",", "").replace("٬", ""))
    try:
        return int(round(float(t))) if t not in ("", "-", ".") else 0
    except Exception:
        return 0


def norm_date(v):
    """هر ورودی تاریخ شمسی → 'YYYY/MM/DD' یا ''."""
    p = re.split(r"[/\-.]", _s(v)[:10])
    try:
        y, m, d = int(p[0]), int(p[1]), int(p[2])
        if 1200 < y < 1700 and 1 <= m <= 12 and 1 <= d <= 31:
            return "%04d/%02d/%02d" % (y, m, d)
    except Exception:
        pass
    return ""


def to_greg(jdate):
    """'1405/03/02' → datetime.date یا None."""
    p = norm_date(jdate)
    if not p:
        return None
    try:
        try:
            from core_utils import jalali_to_gregorian
        except Exception:  # pragma: no cover
            from salesmate.core_utils import jalali_to_gregorian
        y, m, d = [int(x) for x in p.split("/")]
        g = jalali_to_gregorian(y, m, d)
        return date(int(g[0]), int(g[1]), int(g[2]))
    except Exception:
        return None


def today_jalali(today=None):
    t = today or date.today()
    try:
        from core_utils import gregorian_to_jalali
    except Exception:  # pragma: no cover
        from salesmate.core_utils import gregorian_to_jalali
    y, m, d = gregorian_to_jalali(t.year, t.month, t.day)
    return "%04d/%02d/%02d" % (y, m, d)


def status_of(handed, collected, returned):
    if _s(returned):
        return ST_BACK
    if _s(collected):
        return ST_DONE
    if _s(handed):
        return ST_TRANSIT
    return ST_HAND


def is_sales_row(descr, account):
    """اجاره، سود سپرده و اسناد شخصی «چک مشتری» نیستند."""
    t = _s(descr) + " " + _s(account)
    return not any(k in t for k in ("اجاره", "سود", "اسناد شخصی"))


def parse_rows(rows):
    """rows: لیست tuple/لیست سلول‌های شیت AMISA (بدون سطر عنوان).
    ترتیب ستون‌ها: ردیف، ۱..۴، فرم، تاریخ فرم، شماره چک، تاریخ چک، مبلغ، بانک، واگذاری، وصول، برگشت، کلر، روز، شرح، طرف، حساب.
    فقط ردیف‌هایی که شمارهٔ چک دارند (ردیف‌های سود/موجودی اول دوره کنار گذاشته می‌شوند)."""
    out = []
    for r in rows:
        r = list(r) + [None] * (19 - len(r))
        cheque_no = _s(r[7])
        if not cheque_no:
            continue
        handed, coll, ret = norm_date(r[11]), norm_date(r[12]), norm_date(r[13])
        descr, party, account = _s(r[16]), _s(r[17]), _s(r[18])
        out.append({
            "row_no": _num(r[0]), "form_no": _s(r[5]), "form_date": norm_date(r[6]),
            "cheque_no": cheque_no, "due_date": norm_date(r[8]), "amount": _num(r[9]),
            "bank": _s(r[10]), "handed_date": handed, "collected_date": coll, "returned_date": ret,
            "days": _num(r[15]), "descr": descr, "party": party, "account": account,
            "status": status_of(handed, coll, ret), "is_sales": 1 if is_sales_row(descr, account) else 0,
        })
    return out


def read_workbook(path):
    """سطر ۱ = عنوان گروه‌ها، سطر ۲ = عنوان ستون‌ها، داده از سطر ۳ (مثل خروجی AMISA)."""
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        ws = wb.worksheets[0]
        rows = list(ws.iter_rows(min_row=3, values_only=True))
    finally:
        wb.close()
    return parse_rows(rows)


# ---------- ذخیره‌سازی محلی ----------
def _open(db_path):
    c = sqlite3.connect(str(db_path))
    c.execute(SCHEMA)
    return c


def replace_all(db_path, recs):
    """هر بار بارگذاری، همهٔ چک‌ها را جایگزین می‌کند (اکسل منبع اصلی است)."""
    c = _open(db_path)
    try:
        c.execute("DELETE FROM cheques")
        c.executemany(
            "INSERT INTO cheques(%s,status,is_sales) VALUES(%s)" % (",".join(COLS), ",".join("?" * (len(COLS) + 2))),
            [tuple(r[k] for k in COLS) + (r["status"], r["is_sales"]) for r in recs])
        c.commit()
    finally:
        c.close()
    return len(recs)


def row_key(r):
    """هویت یک چک برای ادغام (تاریخ‌های وضعیت عمداً در کلید نیست تا تغییر وضعیت = به‌روزرسانی شود)."""
    return (r["cheque_no"], r["bank"], int(r["amount"] or 0), r["due_date"], r["party"])


def merge_into(db_path, recs):
    """ادغام: چک‌های فایل جدید جایگزین همان چک‌ها (با وضعیت تازه) می‌شوند؛ چک‌هایی که در فایل جدید نیستند حفظ می‌شوند.
    قبل از تغییر، نسخهٔ پشتیبان cheques.bak کنار فایل ساخته می‌شود. خروجی: (جدید، به‌روز، حفظ‌شده)."""
    import os
    import shutil
    old = load_all(db_path)
    if os.path.exists(str(db_path)):
        try:
            shutil.copyfile(str(db_path), str(db_path) + ".bak")
        except Exception:
            pass
    new_keys = {row_key(r) for r in recs}
    old_keys = {row_key(r) for r in old}
    kept = [r for r in old if row_key(r) not in new_keys]
    added = len(new_keys - old_keys)
    updated = len(new_keys & old_keys)
    replace_all(db_path, kept + list(recs))
    return added, updated, len(kept)


def load_all(db_path):
    c = _open(db_path)
    try:
        cur = c.execute("SELECT %s,status,is_sales FROM cheques" % ",".join(COLS))
        keys = COLS + ["status", "is_sales"]
        return [dict(zip(keys, row)) for row in cur.fetchall()]
    finally:
        c.close()


# ---------- گزارش‌ها ----------
def filter_rows(recs, status=None, bank=None, text="", date_from="", date_to="", sales_only=True):
    t = _s(text).lower()
    df, dt = norm_date(date_from), norm_date(date_to)
    out = []
    for r in recs:
        if sales_only and not r["is_sales"]:
            continue
        if status and r["status"] != status:
            continue
        if bank and r["bank"] != bank:
            continue
        if t and t not in (r["party"] + " " + r["cheque_no"] + " " + r["descr"]).lower():
            continue
        if df and (not r["due_date"] or r["due_date"] < df):
            continue
        if dt and (not r["due_date"] or r["due_date"] > dt):
            continue
        out.append(r)
    return out


def totals_by_status(recs):
    t = {k: {"n": 0, "sum": 0} for k in ST_LABEL}
    for r in recs:
        t[r["status"]]["n"] += 1
        t[r["status"]]["sum"] += r["amount"]
    return t


def due_report(recs, today=None):
    """چک‌های باز (در دست/در راه) بر اساس سررسید:
    old = سررسید بیش از ۱ سال پیش (اغلب موجودی اول دوره، جدا نگه داشته می‌شود)؛
    overdue = سررسید گذشته (تا ۱ سال) و هنوز وصول نشده؛ w7 = ۷ روز آینده؛ d30 = ۸ تا ۳۰ روز؛ later = بعدتر."""
    now = today or date.today()
    g = {"old": [], "overdue": [], "w7": [], "d30": [], "later": [], "nodate": []}
    for r in recs:
        if r["status"] not in OPEN_STATES:
            continue
        d = to_greg(r["due_date"])
        if d is None:
            g["nodate"].append(r)
            continue
        diff = (d - now).days
        r = dict(r, left=diff)
        key = "old" if diff < -OLD_DAYS else "overdue" if diff < 0 else "w7" if diff <= 7 else "d30" if diff <= 30 else "later"
        g[key].append(r)
    for k in g:
        g[k].sort(key=lambda x: x["due_date"])
    return g


def sum_amount(rows):
    return sum(r["amount"] for r in rows)


def weekly_flow(recs, weeks=8, today=None):
    """پیش‌بینی ورودی هفتگی: جمع چک‌های باز بر اساس هفتهٔ سررسید (۷روزه از امروز)؛ سررسید گذشته در ردیف اول."""
    now = today or date.today()
    rows = [{"label": "قدیمی (بیش از ۱ سال)", "n": 0, "sum": 0}, {"label": "سررسید گذشته", "n": 0, "sum": 0}]
    for i in range(weeks):
        rows.append({"label": "هفته %d" % (i + 1), "n": 0, "sum": 0, "i": i})
    rows.append({"label": "بعدتر", "n": 0, "sum": 0})
    for r in recs:
        if r["status"] not in OPEN_STATES:
            continue
        d = to_greg(r["due_date"])
        if d is None:
            continue
        diff = (d - now).days
        if diff < 0:
            idx = 0 if diff < -OLD_DAYS else 1
        else:
            idx = 2 + diff // 7 if diff // 7 < weeks else len(rows) - 1
        rows[idx]["n"] += 1
        rows[idx]["sum"] += r["amount"]
    for i, w in enumerate(rows[2:2 + weeks]):
        a = now.toordinal() + i * 7
        w["from"], w["to"] = date.fromordinal(a), date.fromordinal(a + 6)
    return rows


def customer_summary(recs, name, keyfn):
    """خلاصهٔ چک‌های یک مشتری (تطبیق نام با همان customer_key برنامه)."""
    k = keyfn(name)
    mine = [r for r in recs if r["is_sales"] and keyfn(r["party"]) == k]
    tot = totals_by_status(mine)
    return {"rows": sorted(mine, key=lambda r: r["due_date"], reverse=True), "tot": tot,
            "open_sum": tot[ST_HAND]["sum"] + tot[ST_TRANSIT]["sum"]}


def customer_table(recs, keyfn):
    """جدول همهٔ مشتری‌ها: چک در دست، در راه، وصول‌شده، برگشتی."""
    m = {}
    for r in recs:
        if not r["is_sales"]:
            continue
        k = keyfn(r["party"])
        e = m.setdefault(k, {"name": r["party"], "hand": 0, "transit": 0, "done": 0, "back": 0, "n": 0})
        e[r["status"]] += r["amount"]
        e["n"] += 1
    return sorted(m.values(), key=lambda e: -(e["hand"] + e["transit"] + e["back"]))


TRANSIT_GRACE_DAYS = 14


def is_transit(r, today=None):
    """«در راه»: واگذار شده، وصول/برگشت نخورده، و سررسیدش حداکثر ۲ هفته قبل از امروز (یا بعد از آن) باشد."""
    if r["status"] != ST_TRANSIT:
        return False
    d = to_greg(r["due_date"])
    if d is None:
        return False
    return (d - (today or date.today())).days >= -TRANSIT_GRACE_DAYS


def transit_by_customer(recs, keyfn, today=None):
    """چک‌های «در راه» هر مشتری: {کلید نام: [چک‌ها بر اساس سررسید]}."""
    m = {}
    for r in recs:
        if r["is_sales"] and is_transit(r, today):
            m.setdefault(keyfn(r["party"]), []).append(r)
    for v in m.values():
        v.sort(key=lambda r: r["due_date"])
    return m


SNAP_KEY = "cheques_transit"


def build_transit_snapshot(recs, my_keys, keyfn, now_iso=""):
    """اسنپ‌شات اپ موبایل: فقط چک‌های «در راه» مشتری‌هایی که کلیدشان در my_keys است (مشتری‌های خود مالک).
    فقط نام مشتری، تاریخ چک، مبلغ و شماره چک — بدون بانک و شماره حساب.
    {"v":1,"at":..., "customers": {نام: [[تاریخ, مبلغ, شماره چک], ...]}}"""
    out = {}
    for k, rows in transit_by_customer(recs, keyfn).items():
        if k in my_keys:
            out[rows[0]["party"]] = [[r["due_date"], r["amount"], r["cheque_no"]] for r in rows]
    return {"v": 1, "at": now_iso, "customers": out}


def build_coworker_snapshots(recs, keys_by_assignee, keyfn, now_iso="", today=None):
    """برای هر همکار: فقط چک‌های «در راه» مشتری‌های واگذارشده‌ی خودش (نام، تاریخ، مبلغ، شماره چک).
    keys_by_assignee: {uid: {کلید نام مشتری, ...}}. بانک/حساب/چک‌های دیگران هرگز نمی‌رود."""
    tm = transit_by_customer(recs, keyfn, today)
    out = {}
    for uid, keys in keys_by_assignee.items():
        cust = {}
        for k in keys:
            rows = tm.get(k)
            if rows:
                cust[rows[0]["party"]] = [[r["due_date"], r["amount"], r["cheque_no"]] for r in rows]
        out[uid] = {"v": 1, "at": now_iso, "customers": cust}
    return out


def push_coworker_cheques(request, snaps, last_hash=None, now_iso=""):
    """ردیف هر همکار را در coworker_snapshots (ستون cheques) به‌روز می‌کند؛ اگر محتوا تغییر نکرده ارسال نمی‌شود."""
    import json
    sent, hashes = [], dict(last_hash or {})
    for uid, payload in snaps.items():
        core = {k: v for k, v in payload.items() if k != "at"}
        h = json.dumps(core, ensure_ascii=False, sort_keys=True)
        if hashes.get(uid) == h:
            continue
        request("POST", "/rest/v1/coworker_snapshots?on_conflict=assignee",
                [{"assignee": uid, "cheques": payload, "updated_at": now_iso}],
                {"Prefer": "resolution=merge-duplicates,return=minimal"})
        hashes[uid] = h
        sent.append(uid)
    return sent, hashes


def cloud_rows_to_recs(payload, today=None):
    """اسنپ‌شات ابری همکار → همان ساختار رکورد محلی؛ دوباره با قانون ۲ هفته فیلتر می‌شود (اسنپ‌شات ممکن است تا یک روز قدیمی باشد)."""
    out = []
    for name, rows in ((payload or {}).get("customers") or {}).items():
        for r in rows:
            rec = {"party": name, "due_date": norm_date(r[0]), "amount": int(r[1] or 0),
                   "cheque_no": str(r[2] if len(r) > 2 else ""), "status": ST_TRANSIT, "is_sales": 1}
            if is_transit(rec, today):
                out.append(rec)
    return out
