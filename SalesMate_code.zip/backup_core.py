# -*- coding: utf-8 -*-
"""پشتیبان کامل و بازیابی — هستهٔ بدون Qt (قابل تست).

یک فایل zip شامل: حواله‌ها/فروش، چک‌ها، نگاشت‌های بالانس، اطلاعات مشتری‌ها، تنظیمات، استعلام‌ها،
فایل‌های تحلیل فروش (پوشهٔ analysis_data و کش)، و (در صورت آنلاین بودن) مشتری‌های سپرده‌شده به همکارها.
علاوه بر آن اکسل‌های خوانا از حواله‌ها و چک‌ها تا حتی بدون برنامه قابل مشاهده باشد. بدون رمز.
"""
import hashlib
import json
import os
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path

FORMAT = 1
DB_FILES = ("salesmate.db", "cheques.db")
FILES = (
    "salesmate.db", "cheques.db", "customer_contacts.json", "settings.json", "inventory.json",
    "inventory_balance.json", "calc_customers.json", "inquiries.json", "inquiry_prune_declined.json",
    "analysis_selected_customers.json", "analysis_upload_reports.json", "analysis_sales_cache.pkl",
    "samples_stands.csv", "import_1405_invoices.json", "coworker_sent.json", "coworker_assignments_cache.json",
)
DIRS = ("analysis_data", "attachments")
NEVER_RESTORE = {"supabase_session.json"}      # نشست ورود هرگز در پشتیبان نمی‌رود و برنامه برنمی‌گرداند


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _db_copy(src, dst):
    """کپی سازگار از sqlite (حتی وقتی برنامه باز است)."""
    a = sqlite3.connect(str(src))
    try:
        b = sqlite3.connect(str(dst))
        try:
            a.backup(b)
        finally:
            b.close()
    finally:
        a.close()


def _table_to_xlsx(db_path, table, out_path):
    from openpyxl import Workbook
    c = sqlite3.connect(str(db_path))
    try:
        cur = c.execute("SELECT * FROM %s" % table)
        cols = [d[0] for d in cur.description]
        wb = Workbook(write_only=True)
        ws = wb.create_sheet(table)
        ws.append(cols)
        n = 0
        for row in cur:
            ws.append([("" if v is None else (v if isinstance(v, (int, float, str)) else str(v))) for v in row])
            n += 1
        wb.save(str(out_path))
        return n
    finally:
        c.close()


def collect(app_dir):
    """فهرست (مسیر نسبی، مسیر کامل) فایل‌هایی که در پشتیبان می‌روند."""
    app_dir = Path(app_dir)
    out = []
    for name in FILES:
        p = app_dir / name
        if p.is_file():
            out.append((name, p))
    for d in DIRS:
        base = app_dir / d
        if base.is_dir():
            for p in sorted(base.rglob("*")):
                if p.is_file():
                    out.append((str(p.relative_to(app_dir)).replace("\\", "/"), p))
    return out


def create_backup(zip_path, app_dir, app_version="", extra_json=None):
    """ساخت پشتیبان. extra_json: {نام فایل داخل cloud/: داده} مثل مشتری‌های همکارها. خروجی: خلاصه."""
    app_dir = Path(app_dir)
    tmp = Path(tempfile.mkdtemp(prefix="sm_backup_"))
    files, counts = {}, {}
    try:
        with zipfile.ZipFile(str(zip_path), "w", zipfile.ZIP_DEFLATED) as z:
            for rel, p in collect(app_dir):
                src = p
                if rel in DB_FILES:
                    src = tmp / rel
                    _db_copy(p, src)
                z.write(str(src), "data/" + rel)
                files[rel] = {"sha256": _sha(src), "size": os.path.getsize(str(src))}
            # اکسل‌های خوانا
            for dbn, table, xl in (("salesmate.db", "invoices", "invoices.xlsx"), ("cheques.db", "cheques", "cheques.xlsx")):
                if dbn in files:
                    try:
                        out = tmp / xl
                        counts[table] = _table_to_xlsx(tmp / dbn, table, out)
                        z.write(str(out), "readable/" + xl)
                    except Exception:
                        pass
            for name, data in (extra_json or {}).items():
                z.writestr("cloud/" + name, json.dumps(data, ensure_ascii=False, indent=1))
            manifest = {"format": FORMAT, "app_version": app_version, "created": datetime.now().isoformat(timespec="seconds"),
                        "files": files, "counts": counts, "cloud": sorted((extra_json or {}).keys())}
            z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=1))
        return {"files": len(files), "counts": counts, "size": os.path.getsize(str(zip_path)), "cloud": manifest["cloud"]}
    finally:
        shutil.rmtree(str(tmp), ignore_errors=True)


def inspect_backup(zip_path):
    """خواندن و اعتبارسنجی پشتیبان (بدون تغییر چیزی). خطا → ValueError."""
    try:
        z = zipfile.ZipFile(str(zip_path))
    except Exception:
        raise ValueError("فایل zip معتبر نیست.")
    with z:
        if "manifest.json" not in z.namelist():
            raise ValueError("این فایل پشتیبان SalesMate نیست (manifest.json ندارد).")
        m = json.loads(z.read("manifest.json").decode("utf-8"))
        if int(m.get("format", 0)) != FORMAT:
            raise ValueError("نسخهٔ قالب پشتیبان پشتیبانی نمی‌شود.")
        bad = z.testzip()
        if bad:
            raise ValueError("فایل پشتیبان آسیب دیده است: " + bad)
        for rel, meta in m["files"].items():
            h = hashlib.sha256()
            with z.open("data/" + rel) as f:
                for b in iter(lambda: f.read(1 << 20), b""):
                    h.update(b)
            if h.hexdigest() != meta["sha256"]:
                raise ValueError("محتوای %s با پشتیبان نمی‌خواند (خراب است)." % rel)
    return m


def restore_backup(zip_path, app_dir, safety_dir=None, app_version=""):
    """بازیابی: اول اعتبارسنجی، بعد نسخهٔ ایمنی از وضعیت فعلی، بعد جایگزینی فایل‌ها. خروجی: (تعداد فایل، مسیر نسخه ایمنی)."""
    app_dir = Path(app_dir)
    m = inspect_backup(zip_path)
    safety = None
    sd = Path(safety_dir) if safety_dir else app_dir / "backups"
    sd.mkdir(parents=True, exist_ok=True)
    safety = sd / ("before_restore_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".zip")
    create_backup(safety, app_dir, app_version)
    n = 0
    with zipfile.ZipFile(str(zip_path)) as z:
        for rel in m["files"]:
            if Path(rel).name in NEVER_RESTORE:
                continue
            dest = app_dir / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            tmp = dest.with_name(dest.name + ".restore_tmp")
            with z.open("data/" + rel) as src, open(str(tmp), "wb") as out:
                shutil.copyfileobj(src, out)
            os.replace(str(tmp), str(dest))
            n += 1
    return n, str(safety)


def esfand_warning(today_j, last_backup_j):
    """از ۲۰ام اسفند تا وقتی پشتیبان کامل گرفته نشده هشدار بده. تاریخ‌ها 'YYYY/MM/DD'."""
    try:
        y, m, d = [int(x) for x in str(today_j).split("/")]
    except Exception:
        return False
    if m != 12 or d < 20:
        return False
    return not last_backup_j or str(last_backup_j) < "%04d/12/20" % y
